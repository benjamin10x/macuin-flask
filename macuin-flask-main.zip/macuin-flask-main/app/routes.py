from flask import Blueprint, render_template, request, redirect, url_for, flash

main = Blueprint("main", __name__)

@main.route("/")
def index():
    return render_template("inicio_sesion.html")

@main.route("/acceso", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        
        # Aquí iría la lógica de autenticación
        if email == "empleado@macuin.com" and password == "admin123":
            flash("Inicio de sesión exitoso", "success")
            return redirect(url_for("main.pedidos"))
        else:
            flash("Credenciales incorrectas", "error")
    
    return render_template("inicio_sesion.html")

@main.route("/pedidos")
def orders():
    search_query = request.args.get("buscar", "")
    return render_template("gestion_pedidos.html", search=search_query)

@main.route("/partes")
def parts():
    # Página de listado de autopartes
    return render_template("lista_autopartes.html")

@main.route("/partes/agregar", methods=["GET", "POST"])
def add_part():
    if request.method == "POST":
        nombre = request.form.get("nombre")
        categoria = request.form.get("categoria")
        precio = request.form.get("precio")
        stock = request.form.get("stock")
        
        # Aquí iría la lógica para guardar la autoparte
        flash(f"Autoparte '{nombre}' agregada exitosamente", "success")
        return redirect(url_for("main.parts"))
    
    return render_template("agregar_autoparte.html")